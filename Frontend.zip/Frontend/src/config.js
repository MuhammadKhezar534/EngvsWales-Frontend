export const base_url = "http://ec2-54-157-32-140.compute-1.amazonaws.com/api";

// export const base_url = "http://localhost:3006";
