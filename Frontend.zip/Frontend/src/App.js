import Routes from "./routes";
import "./App.css";

function App() {
  return (
    <div className="app-container">
      <Routes />
    </div>
  );
}

export default App;
