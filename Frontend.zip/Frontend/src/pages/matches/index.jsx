const Matches = () => {
  return <div>Matches</div>;
};

export default Matches;
